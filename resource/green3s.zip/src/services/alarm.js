import { objDateTo } from "@common-ui/Calendar/utils";
import { API_GREEN3S } from "@configs/end-points-url";
import { useAPIFetcher } from "@hooks/useAPIFetcher";
import { useEffect } from "react";

export const useFetchAlarm = ({ startDate, endDate, stationCode }) => {
    const [isReady, setIsReady] = useState(false);

    const res = useAPIFetcher(
        API_GREEN3S.ALARM(objDateTo(startDate, "YYYY-MM-DD"), objDateTo(endDate, "YYYY-MM-DD"), stationCode),
        {
            revalidateIfStale: true,
            dedupingInterval: 60000,
            use: [noCache],
        }
    );

    useEffect(() => {
        setTimeout(() => {
            setIsReady(true);
        }, 500);
    }, []);

    return {
        ...res,
        rData: isReady ? res.data : undefined,
        rIsValidating: isReady ? res.isValidating : true,
    };
};
