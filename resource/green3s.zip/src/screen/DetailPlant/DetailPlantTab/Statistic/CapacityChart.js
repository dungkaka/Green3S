import { AppText, AppTextMedium } from "@common-ui/AppText";
import EchartsWebView from "@common-ui/EchartsWebView";
import { ModalDatePicker } from "@common-ui/Calendar/DatePicker";
import { ColorDefault } from "@theme/";
import { Color } from "@theme/colors";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, View } from "react-native";
import styles from "./styles.index";
import { AntDesign } from "@expo/vector-icons";
import { useDispatch } from "react-redux";
import { closeIconLoadingOverlay, openIconLoadingOverlay } from "@redux/actions/app";
import { useOnlyDidUpdateEffect } from "@hooks/useOnlyDidUpdateEffect";
import { time } from "@utils/helps/time";
import { useFetchDetailPlant, useFetchPowerByTime } from "@services/factory";
import { useRoute } from "@react-navigation/native";
import { round2 } from "@utils/helps/functions";

const initEndDate = time().toDateObject();

const CapacityChart = () => {
    const { params } = useRoute();
    const dispatch = useDispatch();
    const chartRef = useRef();

    const { stationCode } = params ? params : {};
    const modalDatePickerRef = useRef();
    const [date, setDate] = useState(initEndDate);
    const resPlant = useFetchDetailPlant({ station_code: stationCode });
    const { data, isValidating, error, mutate } = useFetchPowerByTime({
        stationCode,
        date: date,
        firmId: resPlant.data?.data?.cpt_firm_id,
    });

    const dataChart = data?.data_chart_power || [];

    const option = useMemo(
        () => ({
            grid: {
                top: 80,
                bottom: 50,
                left: 45,
                right: 25,
            },
            xAxis: {
                type: "category",
                data: dataChart.map((data) => data.created_at.slice(11)),
                axisLabel: {
                    color: Color.gray_6,
                    fontSize: 11,
                },
                axisLine: {
                    lineStyle: {
                        color: Color.gray_6,
                    },
                },
            },
            yAxis: {
                type: "value",
                name: "kWh",
                nameTextStyle: {
                    color: Color.gray_6,
                },
                axisLabel: {
                    color: Color.gray_6,
                    fontSize: 11,
                },
                axisLine: {
                    show: true,
                    lineStyle: {
                        color: Color.gray_5,
                    },
                },
            },
            series: [
                {
                    name: "Công suất",
                    data: dataChart.map((data) => round2(data.cap_now) || 0),
                    type: "line",
                    smooth: true,
                    showSymbol: false,
                    itemStyle: {
                        color: ColorDefault.primary,
                    },
                    // areaStyle: `{
                    //     color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    //         {
                    //             offset: 0,
                    //             color: "rgb(255, 158, 68)",
                    //         },
                    //         {
                    //             offset: 1,
                    //             color: "rgb(255, 70, 131)",
                    //         },
                    //     ]),
                    // }`,
                },
            ],
            tooltip: {
                trigger: "axis",
                backgroundColor: "rgba(255,255,255,0.9)",
                borderWidth: 0,
                axisPointer: {
                    type: "shadow",
                },
            },
            legend: {
                top: 10,
                left: 10,
                icon: "circle",
                data: ["Công suất"],
                itemHeight: 10,
            },
        }),
        [data]
    );

    return (
        <View style={styles.container}>
            <View style={styles.titleContainer}>
                <AppTextMedium style={styles.title}>Công suất</AppTextMedium>
            </View>
            <View style={styles.dateContainer}>
                <Pressable>
                    <AppTextMedium style={styles.dateDirectItem}>{`<    `}</AppTextMedium>
                </Pressable>
                <Pressable
                    onPress={() => {
                        modalDatePickerRef.current.open(date);
                    }}
                    style={styles.displayDate}
                >
                    <AntDesign name="calendar" size={17} color={Color.gray_8} />
                    <AppTextMedium style={styles.textDateDisplay}>
                        {date.day}/{date.month}/{date.year}
                    </AppTextMedium>
                </Pressable>
                <Pressable>
                    <AppTextMedium style={styles.dateDirectItem}>{`    >`}</AppTextMedium>
                </Pressable>
            </View>

            <ModalDatePicker
                ref={modalDatePickerRef}
                delayRender={300}
                onOk={(close) => {
                    close();
                    setDate(modalDatePickerRef.current.getData().date);
                }}
            />

            <View style={styles.echartContainer}>
                <EchartsWebView ref={chartRef} option={option} delayRender={300} />
                {isValidating ? (
                    <View
                        style={{
                            ...StyleSheet.absoluteFill,
                            backgroundColor: "rgba(255,255,255,0.3)",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    >
                        <ActivityIndicator size={42} color={Color.gray_6} animating={true} />
                    </View>
                ) : null}
            </View>
        </View>
    );
};

export default CapacityChart;
