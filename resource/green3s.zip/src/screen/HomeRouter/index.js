import React from "react";
import TabNavigation from "./navigation";

const HomeRouter = () => {
    return <TabNavigation />;
};

export default HomeRouter;
