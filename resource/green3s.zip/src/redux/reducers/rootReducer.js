import { appModal } from "./appModal";

export const plainReducer = { appModal };