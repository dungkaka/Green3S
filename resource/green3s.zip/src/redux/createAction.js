export const createAction = (type, payload) => ({
    type: type,
    payload: payload,
});
